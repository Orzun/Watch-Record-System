﻿Imports System.Data.OleDb
Public Class shop
    Dim con As New OleDb.OleDbConnection
    Dim ds As New DataSet
    Dim da As New OleDbDataAdapter
    Dim inc As Integer
    Dim MaxRows As Integer
    Private Sub shop_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Watch_recordsDataSet.watchshop' table. You can move, or remove it, as needed.
        Me.WatchshopTableAdapter.Fill(Me.Watch_recordsDataSet.watchshop)
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        da = New OleDbDataAdapter("select * from watchshop", con)
        da.Fill(ds, "watchshop")
        con.Close()
        MaxRows = ds.Tables("watchshop").Rows.Count
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cb As New OleDb.OleDbCommandBuilder(da)
        Dim dsnewrow As DataRow
        Try
            dsnewrow = ds.Tables("watchshop").NewRow()
            dsnewrow.Item("Wshp_Id") = TextBox1.Text
            dsnewrow.Item("Wshp_Name") = TextBox2.Text
            dsnewrow.Item("Wshp_Location") = TextBox3.Text
            dsnewrow.Item("Wshp_PAN_Number") = TextBox4.Text
            dsnewrow.Item("Wshp_Contact") = TextBox5.Text
            ds.Tables("watchshop").Rows.Add(dsnewrow)
            da.Update(ds, "watchshop")
            MsgBox("New Record added to database")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        Dim str As String
        str = "Update [watchshop] set[Wshp_Id] = '" & TextBox1.Text & "' ,[Wshp_Name]='" & TextBox2.Text & "',[Wshp_Location]='" & TextBox3.Text & "',[Wshp_PAN_Number]='" & TextBox4.Text & "',[Wshp_Contact]='" & TextBox5.Text & "' where [Wshp_Id] = " & TextBox1.Text & ""
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            con.Close()
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            MsgBox("Updated sucessfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        Dim str As String
        str = "delete from [watchshop] where [Wshp_Id] = " & TextBox1.Text & ""
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            con.Close()
            TextBox1.Clear()
            MsgBox("Deleted sucessfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        BindingContext(Watch_recordsDataSet, "watchshop").Position = BindingContext(Watch_recordsDataSet, "watchshop").Position + 1
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        BindingContext(Watch_recordsDataSet, "watchshop").Position = BindingContext(Watch_recordsDataSet, "watchshop").Position - 1
    End Sub
    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Me.Hide()
        menuitem.Show()
    End Sub
End Class