﻿Imports System.Data.OleDb
Public Class supplier
    Dim con As New OleDb.OleDbConnection
    Dim ds As New DataSet
    Dim da As New OleDbDataAdapter
    Dim inc As Integer
    Dim MaxRows As Integer
    Private Sub supplier_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Watch_recordsDataSet.supplier' table. You can move, or remove it, as needed.
        Me.SupplierTableAdapter.Fill(Me.Watch_recordsDataSet.supplier)
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        da = New OleDbDataAdapter("select * from supplier", con)
        da.Fill(ds, "supplier")
        con.Close()
        MaxRows = ds.Tables("supplier").Rows.Count
    End Sub
    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Me.Hide()
        menuitem.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cb As New OleDb.OleDbCommandBuilder(da)
        Dim dsnewrow As DataRow
        Try
            dsnewrow = ds.Tables("supplier").NewRow()
            dsnewrow.Item("Splr_Id") = TextBox1.Text
            dsnewrow.Item("Splr_Name") = TextBox2.Text
            dsnewrow.Item("Splr_Brand") = TextBox3.Text
            dsnewrow.Item("Splr_Contact_Details") = TextBox4.Text
            dsnewrow.Item("Splr_Address") = TextBox5.Text

            ds.Tables("supplier").Rows.Add(dsnewrow)
            da.Update(ds, "supplier")
            MsgBox("New Record added to database")

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        Dim str As String
        str = "Update [supplier] set[Splr_Id] = '" & TextBox1.Text & "' ,[Splr_Name]='" & TextBox2.Text & "',[Splr_Brand]='" & TextBox3.Text & "',[Splr_Contact_Details]='" & TextBox4.Text & "',[Splr_Address]='" & TextBox5.Text & "' where [Splr_Id] = " & TextBox1.Text & ""
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            con.Close()
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            MsgBox("Updated sucessfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        Dim str As String
        str = "delete from [supplier] where [Splr_Id] = " & TextBox1.Text & ""
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            con.Close()
            TextBox1.Clear()
            MsgBox("Deleted sucessfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        BindingContext(Watch_recordsDataSet, "supplier").Position = BindingContext(Watch_recordsDataSet, "supplier").Position + 1
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        BindingContext(Watch_recordsDataSet, "supplier").Position = BindingContext(Watch_recordsDataSet, "supplier").Position - 1
    End Sub
End Class