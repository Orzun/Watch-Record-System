﻿Public Class Form2

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'getting input value from form
        Dim username As String = TextBox1.Text
        Dim userpass As String = TextBox1.Text

        'static username and password
        Dim user1 As String = "admin"
        Dim user1pass As String = "admin"

        'validating user inputs when button submitted
        If TextBox1.Text = user1 And TextBox2.Text = user1pass Then
            Me.Hide()
            menuitem.Show()
        ElseIf TextBox1.Text = "" And TextBox2.Text = "" Then
            MsgBox("Please Enter name and password")
        ElseIf TextBox1.Text = "" And TextBox2.Text = user1pass Then
            MsgBox("Please enter password")
        ElseIf TextBox1.Text = user1 And TextBox2.Text = "" Then
            MsgBox("Please enter username")
        ElseIf TextBox1.Text <> user1 And TextBox2.Text <> user1pass Then
            MsgBox("User name and password incorrect")
        ElseIf TextBox2.Text <> user1pass Then
            MsgBox("Username is incorrect")
        ElseIf TextBox1.Text <> user1 Then
            MsgBox("Password is incorrect")
        End If

    End Sub
End Class