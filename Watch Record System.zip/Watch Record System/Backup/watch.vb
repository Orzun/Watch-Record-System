﻿Imports System.Data.OleDb
Public Class watch
    Dim con As New OleDb.OleDbConnection
    Dim ds As New DataSet
    Dim da As New OleDbDataAdapter
    Dim MaxRows As Integer
    Private Sub mobile_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Watch_recordsDataSet.watch' table. You can move, or remove it, as needed.
        Me.WatchTableAdapter.Fill(Me.Watch_recordsDataSet.watch)
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        da = New OleDbDataAdapter("select * from watch", con)
        da.Fill(ds, "watch")
        con.Close()
        MaxRows = ds.Tables("watch").Rows.Count
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Me.Hide()
        menuitem.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cb As New OleDb.OleDbCommandBuilder(da)
        Dim dsnewrow As DataRow
        Try
            dsnewrow = ds.Tables("watch").NewRow()
            dsnewrow.Item("Wch_Id") = TextBox1.Text
            dsnewrow.Item("Wch_Model") = TextBox2.Text
            dsnewrow.Item("Wch_Serial_No") = TextBox3.Text
            dsnewrow.Item("Wch_Cost_Price") = TextBox4.Text
            dsnewrow.Item("Wch_Selling_Price") = TextBox5.Text
            dsnewrow.Item("Wch_Warranty_In_Years") = TextBox6.Text
            dsnewrow.Item("Wch_Manufacturer") = TextBox6.Text
            dsnewrow.Item("Wch_Made_In") = TextBox6.Text
            ds.Tables("watch").Rows.Add(dsnewrow)
            da.Update(ds, "watch")
            MsgBox("New Record added to database")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        Dim str As String
        str = "Update [watch] set[Wch_Id] = '" & TextBox1.Text & "' ,[Wch_Model]='" & TextBox2.Text & "',[Wch_Serial_No]='" & TextBox3.Text & "',[Wch_Cost_Price]='" & TextBox4.Text & "',[Wch_Selling_Price]='" & TextBox5.Text & "',[Wch_Warranty_In_Years]='" & TextBox6.Text & "',[Wch_Manufacturer]='" & TextBox7.Text & "',[Wch_Made_In]='" & TextBox8.Text & "' where [Wch_Id] = " & TextBox1.Text & ""
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            con.Close()
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
            TextBox7.Clear()
            TextBox8.Clear()
            MsgBox("Updated sucessfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        Dim str As String
        str = "delete from [watch] where [Wch_Id] = " & TextBox1.Text & ""
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            con.Close()
            TextBox1.Clear()
            MsgBox("Deleted sucessfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        BindingContext(Watch_recordsDataSet, "watch").Position = BindingContext(Watch_recordsDataSet, "watch").Position + 1
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        BindingContext(Watch_recordsDataSet, "watch").Position = BindingContext(Watch_recordsDataSet, "watch").Position - 1
    End Sub
End Class