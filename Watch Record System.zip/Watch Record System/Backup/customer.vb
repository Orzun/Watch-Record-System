﻿Imports System.Data.OleDb

Public Class customer
    Dim con As New OleDb.OleDbConnection
    Dim ds As New DataSet
    Dim da As New OleDbDataAdapter
    Dim MaxRows As Integer

    Private Sub Admin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Watch_recordsDataSet.customer' table. You can move, or remove it, as needed.
        Me.CustomerTableAdapter.Fill(Me.Watch_recordsDataSet.customer)
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        da = New OleDbDataAdapter("select * from customer", con)
        da.Fill(ds, "customer")
        con.Close()
        MaxRows = ds.Tables("customer").Rows.Count
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim cb As New OleDb.OleDbCommandBuilder(da)
        Dim dsnewrow As DataRow
        Try
            dsnewrow = ds.Tables("customer").NewRow()
            dsnewrow.Item("Cust_Id") = TextBox1.Text
            dsnewrow.Item("Cust_FirstName") = TextBox2.Text
            dsnewrow.Item("Cust_LastName") = TextBox3.Text
            dsnewrow.Item("Cust_Contact_Details") = TextBox4.Text
            dsnewrow.Item("Cust_Address") = TextBox5.Text
            dsnewrow.Item("Cust_Email") = TextBox6.Text
            ds.Tables("customer").Rows.Add(dsnewrow)
            da.Update(ds, "customer")
            MsgBox("New Record added to database")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        Dim str As String
        str = "delete from [customer] where [Cust_Id] = " & TextBox1.Text & ""
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            con.Close()
            TextBox1.Clear()
            MsgBox("Deleted sucessfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Me.Hide()
        menuitem.Show()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        BindingContext(Watch_recordsDataSet, "customer").Position = BindingContext(Watch_recordsDataSet, "customer").Position - 1
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        BindingContext(Watch_recordsDataSet, "customer").Position = BindingContext(Watch_recordsDataSet, "customer").Position + 1
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='C:\Users\User\Desktop\myproject\Watch Record System\watch_records.accdb'"
        con.Open()
        Dim str As String
        str = "Update [customer] set[Cust_Id] = '" & TextBox1.Text & "' ,[Cust_FirstName]='" & TextBox2.Text & "',[Cust_LastName]='" & TextBox3.Text & "',[Cust_Contact_Details]='" & TextBox4.Text & "',[Cust_Address]='" & TextBox5.Text & "',[Cust_Email]='" & TextBox6.Text & "' where [Cust_Id] = " & TextBox1.Text & ""
        Dim cmd As OleDbCommand = New OleDbCommand(str, con)
        Try
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            con.Close()
            TextBox1.Clear()
            TextBox2.Clear()
            TextBox3.Clear()
            TextBox4.Clear()
            TextBox5.Clear()
            TextBox6.Clear()
            MsgBox("Updated sucessfully")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class